package com.cg.Service;

import java.util.List;

import com.cg.entities.Account;
//import com.cg.exception.InsufficientFundException;

public interface AccountService {

	public boolean addAccount(Account a);
	public boolean deleteAccount(Account a) ;
	public Account findAccount(String id) ;
	public List<Account> getAllAccounts();
	public void update(String id, Account account);
	
	
}
